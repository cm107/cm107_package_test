def hello():
    print('Hi, how are you?')